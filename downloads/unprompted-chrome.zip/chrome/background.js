// extension/shared/background.js — Service worker: tracking, sync timer

import { DEFAULT_SITES, DEFAULT_IDLE_THRESHOLD_SECONDS, WORKER_URL } from './shared/constants.js';
import { addTime, todayString, getTime } from './shared/schema.js';
import { createStorage, extensionBackend } from './shared/storage.js';
import { sync } from './shared/sync.js';

const storage = createStorage(extensionBackend());

// --- In-memory tracking state ---
let activeSession = null;   // { site, startTime }
let idle = false;
let lastInteractionAt = Date.now();

// --- Helpers ---

function extractSite(url) {
  try {
    const hostname = new URL(url).hostname;
    return DEFAULT_SITES.find(s => hostname === s || hostname.endsWith('.' + s)) || null;
  } catch {
    return null;
  }
}

async function flushSession() {
  if (!activeSession) return;
  const elapsed = Math.round((Date.now() - activeSession.startTime) / 1000);
  if (elapsed > 0) {
    const data = await storage.loadData();
    addTime(data, todayString(), activeSession.site, elapsed);
    await storage.saveData(data);
    await checkNudge(data, activeSession.site);
  }
  activeSession = null;
}

function startSession(site) {
  activeSession = { site, startTime: Date.now() };
  idle = false;
}

async function onTabChanged(tabId) {
  await flushSession();
  try {
    const tab = await chrome.tabs.get(tabId);
    const site = extractSite(tab.url);
    if (site) startSession(site);
  } catch {
    // Tab may not exist
  }
}

// --- Tab / window listeners ---

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  await onTabChanged(tabId);
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.url || changeInfo.status === 'complete') {
    // Only care if this is the active tab
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (activeTab && activeTab.id === tabId) {
      await onTabChanged(tabId);
    }
  }
});

chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    // All windows lost focus
    await flushSession();
    return;
  }
  try {
    const [activeTab] = await chrome.tabs.query({ active: true, windowId });
    if (activeTab) await onTabChanged(activeTab.id);
  } catch {
    await flushSession();
  }
});

// --- Nudge ---

async function checkNudge(data, site) {
  const limit = data.limits?.[site];
  if (!limit) return;
  const nudgeAt = data.settings?.nudgeAt ?? 0.9;
  const current = getTime(data, todayString(), site);
  if (current >= limit * nudgeAt) {
    const remaining = Math.max(0, limit - current);
    const minutes = Math.ceil(remaining / 60);
    // Find tabs for this site and send nudge
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (extractSite(tab.url) === site) {
        chrome.tabs.sendMessage(tab.id, {
          type: 'nudge',
          site,
          minutesLeft: minutes,
        }).catch(() => {});
      }
    }
  }
}

// --- Sync alarm ---

chrome.alarms.create('sync', { periodInMinutes: 15 });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'sync') {
    await flushSession();
    await sync(storage, WORKER_URL);
    // Restart session if a tracked tab is still active
    try {
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (activeTab) {
        const site = extractSite(activeTab.url);
        if (site) startSession(site);
      }
    } catch {}
  }
});

// --- All message handling (single listener to avoid Firefox MV2 multi-listener bug) ---

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'heartbeat') {
    lastInteractionAt = msg.lastInteractionAt;
    const thresholdMs = (msg.idleThreshold || DEFAULT_IDLE_THRESHOLD_SECONDS) * 1000;
    const wasIdle = idle;
    idle = (Date.now() - lastInteractionAt) > thresholdMs;

    if (idle && !wasIdle && activeSession) {
      flushSession();
    } else if (!idle && wasIdle) {
      if (sender.tab?.url) {
        const site = extractSite(sender.tab.url);
        if (site) startSession(site);
      }
    }

    // MV3 fix: service worker can suspend and lose activeSession.
    // If heartbeat arrives from a tracked site with no session, start one.
    if (!idle && !activeSession && sender.tab?.url) {
      const site = extractSite(sender.tab.url);
      if (site) startSession(site);
    }

    // Check nudge on every heartbeat so user gets warned even without tab changes
    if (!idle && activeSession) {
      flushSession().then(() => storage.loadData()).then(data => {
        const site = activeSession?.site || extractSite(sender.tab?.url);
        if (site) checkNudge(data, site);
        // Restart session after flush
        if (!activeSession && sender.tab?.url) {
          const s = extractSite(sender.tab.url);
          if (s) startSession(s);
        }
      }).catch(() => {});
    }

    sendResponse({ ok: true });
    return false;
  }

  if (msg.type === 'getData') {
    // Flush current session so popup sees up-to-date numbers
    flushSession().then(() => storage.loadData()).then(data => {
      // Restart session for the tracked tab (flush cleared it)
      if (activeSession === null) {
        chrome.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
          if (tab) {
            const site = extractSite(tab.url);
            if (site) startSession(site);
          }
        }).catch(() => {});
      }
      sendResponse(data);
    });
    return true;
  }

  if (msg.type === 'saveData') {
    storage.saveData(msg.data).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === 'syncNow') {
    flushSession().then(() => sync(storage, WORKER_URL)).then(result => sendResponse(result));
    return true;
  }
});
