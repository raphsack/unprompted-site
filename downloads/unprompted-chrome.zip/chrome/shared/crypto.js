// shared/crypto.js — Key derivation and AES-GCM encrypt/decrypt
// Works in both browser (Web Crypto) and Node.js (globalThis.crypto)

const subtle = globalThis.crypto.subtle;

const HKDF_INFO = new TextEncoder().encode('unprompted-v1');
const HKDF_SALT = new Uint8Array(32); // zero salt — secret_key already has full entropy

/**
 * Generate a new secret key: 32 random bytes as hex, prefixed "stime_"
 */
export function generateSecretKey() {
  const bytes = new Uint8Array(32);
  globalThis.crypto.getRandomValues(bytes);
  return 'stime_' + bytesToHex(bytes);
}

/**
 * Derive the storage key (R2 path) from a secret key.
 * storage_key = SHA-256(secret_key) as hex
 */
export async function deriveStorageKey(secretKey) {
  const encoded = new TextEncoder().encode(secretKey);
  const hash = await subtle.digest('SHA-256', encoded);
  return bytesToHex(new Uint8Array(hash));
}

/**
 * Derive an auth token from a secret key for worker authentication.
 * auth_token = SHA-256(secret_key + ":auth") as hex
 */
export async function deriveAuthToken(secretKey) {
  const encoded = new TextEncoder().encode(secretKey + ':auth');
  const hash = await subtle.digest('SHA-256', encoded);
  return bytesToHex(new Uint8Array(hash));
}

/**
 * Derive an AES-GCM encryption key from a secret key using HKDF-SHA256.
 */
async function deriveEncryptionKey(secretKey) {
  const keyMaterial = await subtle.importKey(
    'raw',
    new TextEncoder().encode(secretKey),
    'HKDF',
    false,
    ['deriveKey']
  );
  return subtle.deriveKey(
    { name: 'HKDF', hash: 'SHA-256', salt: HKDF_SALT, info: HKDF_INFO },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

/**
 * Encrypt a plaintext JSON string with AES-GCM.
 * Returns a base64 string (IV prepended to ciphertext).
 */
export async function encrypt(secretKey, plaintext) {
  const key = await deriveEncryptionKey(secretKey);
  const iv = globalThis.crypto.getRandomValues(new Uint8Array(12));
  const encoded = new TextEncoder().encode(plaintext);
  const ciphertext = await subtle.encrypt({ name: 'AES-GCM', iv }, key, encoded);

  // Prepend 12-byte IV to ciphertext
  const combined = new Uint8Array(iv.length + ciphertext.byteLength);
  combined.set(iv);
  combined.set(new Uint8Array(ciphertext), iv.length);

  return bytesToBase64(combined);
}

/**
 * Decrypt a base64 string (IV + ciphertext) back to plaintext.
 */
export async function decrypt(secretKey, base64Ciphertext) {
  const key = await deriveEncryptionKey(secretKey);
  const combined = base64ToBytes(base64Ciphertext);

  const iv = combined.slice(0, 12);
  const ciphertext = combined.slice(12);

  const decrypted = await subtle.decrypt({ name: 'AES-GCM', iv }, key, ciphertext);
  return new TextDecoder().decode(decrypted);
}

// --- Helpers ---

function bytesToHex(bytes) {
  return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
}

function bytesToBase64(bytes) {
  if (typeof Buffer !== 'undefined') {
    return Buffer.from(bytes).toString('base64');
  }
  // Browser fallback
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}

function base64ToBytes(base64) {
  if (typeof Buffer !== 'undefined') {
    return new Uint8Array(Buffer.from(base64, 'base64'));
  }
  // Browser fallback
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}
