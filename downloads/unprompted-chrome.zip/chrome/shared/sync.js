// shared/sync.js — Encrypt, upload, download, merge
// Depends on crypto.js (encrypt/decrypt, deriveStorageKey) and schema.js (merge, prune)

import { encrypt, decrypt, deriveStorageKey, deriveAuthToken } from './crypto.js';
import { merge, prune, todayString } from './schema.js';

/**
 * Perform a full sync cycle:
 *   1. Download remote blob (if any)
 *   2. Decrypt and max-merge into local
 *   3. Prune old days
 *   4. Encrypt and upload merged blob
 *   5. Save merged blob locally
 *
 * @param {object} storage — from createStorage()
 * @param {string} workerUrl — base URL of Cloudflare Worker (no trailing slash)
 * @param {function} fetchFn — fetch implementation (globalThis.fetch or node-fetch)
 * @returns {{ merged: boolean, uploaded: boolean }} result summary
 */
export async function sync(storage, workerUrl, fetchFn = globalThis.fetch) {
  const secretKey = await storage.getSecretKey();
  if (!secretKey) return { merged: false, uploaded: false };

  const storageKey = await deriveStorageKey(secretKey);
  const authToken = await deriveAuthToken(secretKey);
  const endpoint = `${workerUrl}/sync/${storageKey}`;

  let local = await storage.loadData();
  let merged = false;

  // Download and merge
  const remote = await download(secretKey, authToken, endpoint, fetchFn);
  if (remote) {
    local = merge(local, remote);
    merged = true;
  }

  // Prune rolling window
  local = prune(local, todayString());
  local.meta.lastSyncedAt = new Date().toISOString();

  // Upload
  const uploaded = await upload(secretKey, authToken, endpoint, local, fetchFn);

  // Save locally
  await storage.saveData(local);

  return { merged, uploaded };
}

/**
 * Download and decrypt the remote blob. Returns parsed data or null.
 */
async function download(secretKey, authToken, endpoint, fetchFn) {
  try {
    const res = await fetchFn(endpoint, {
      method: 'GET',
      headers: { 'Authorization': `Bearer ${authToken}` }
    });
    if (!res.ok) return null;
    const { ciphertext } = await res.json();
    if (!ciphertext) return null;
    const plaintext = await decrypt(secretKey, ciphertext);
    return JSON.parse(plaintext);
  } catch {
    return null;
  }
}

/**
 * Encrypt and upload the local blob.
 */
async function upload(secretKey, authToken, endpoint, data, fetchFn) {
  try {
    const plaintext = JSON.stringify(data);
    const ciphertext = await encrypt(secretKey, plaintext);
    const res = await fetchFn(endpoint, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`
      },
      body: JSON.stringify({ ciphertext }),
    });
    return res.ok;
  } catch {
    return false;
  }
}
