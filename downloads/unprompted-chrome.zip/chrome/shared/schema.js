// shared/schema.js — Data model: create, validate, merge, prune

import {
  DEFAULT_IDLE_THRESHOLD_SECONDS,
  DEFAULT_SYNC_INTERVAL_MINUTES,
  DEFAULT_NUDGE_AT,
  ROLLING_DAYS,
  SCHEMA_VERSION,
} from './constants.js';

/**
 * Create a fresh empty data blob.
 */
export function createEmpty() {
  return {
    version: SCHEMA_VERSION,
    days: {},
    limits: {},
    settings: {
      idleThresholdSeconds: DEFAULT_IDLE_THRESHOLD_SECONDS,
      syncIntervalMinutes: DEFAULT_SYNC_INTERVAL_MINUTES,
      nudgeAt: DEFAULT_NUDGE_AT,
    },
    meta: {
      lastSyncedAt: null,
      schemaVersion: SCHEMA_VERSION,
    },
  };
}

/**
 * Add seconds to a site for a given day.
 */
export function addTime(data, date, site, seconds) {
  if (!data.days[date]) data.days[date] = {};
  data.days[date][site] = (data.days[date][site] || 0) + seconds;
  return data;
}

/**
 * Get total seconds for a site on a given day.
 */
export function getTime(data, date, site) {
  return data.days[date]?.[site] || 0;
}

/**
 * Get total seconds across all sites for a given day.
 */
export function getDayTotal(data, date) {
  const day = data.days[date];
  if (!day) return 0;
  return Object.values(day).reduce((sum, s) => sum + s, 0);
}

/**
 * Max-merge two data blobs. Per site per day, take the higher value.
 * Limits and settings are taken from local (the user's device is authoritative).
 */
export function merge(local, remote) {
  const merged = structuredClone(local);

  for (const [date, sites] of Object.entries(remote.days)) {
    if (!merged.days[date]) merged.days[date] = {};
    for (const [site, seconds] of Object.entries(sites)) {
      merged.days[date][site] = Math.max(merged.days[date][site] || 0, seconds);
    }
  }

  return merged;
}

/**
 * Remove days older than ROLLING_DAYS from today.
 */
export function prune(data, today) {
  const cutoff = new Date(today);
  cutoff.setDate(cutoff.getDate() - ROLLING_DAYS);
  const cutoffStr = formatDate(cutoff);

  for (const date of Object.keys(data.days)) {
    if (date < cutoffStr) delete data.days[date];
  }
  return data;
}

/**
 * Format a Date as YYYY-MM-DD.
 */
export function formatDate(d) {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Get today's date string in local time.
 */
export function todayString() {
  return formatDate(new Date());
}
