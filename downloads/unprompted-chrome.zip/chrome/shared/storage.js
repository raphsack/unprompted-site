// shared/storage.js — Local read/write, abstracted per surface
// Each surface provides a backend: { get(key), set(key, value) }

import { createEmpty } from './schema.js';

const DATA_KEY = 'unprompted-data';
const SECRET_KEY_KEY = 'unprompted-secret';

/**
 * Create a storage adapter for a given backend.
 *
 * Backends:
 *   - Browser extension: chrome.storage.local (async)
 *   - Node/CLI: filesystem-based (see nodeBackend below)
 */
export function createStorage(backend) {
  return {
    async loadData() {
      const raw = await backend.get(DATA_KEY);
      if (!raw) return createEmpty();
      return typeof raw === 'string' ? JSON.parse(raw) : raw;
    },

    async saveData(data) {
      await backend.set(DATA_KEY, JSON.stringify(data));
    },

    async getSecretKey() {
      return backend.get(SECRET_KEY_KEY);
    },

    async setSecretKey(key) {
      await backend.set(SECRET_KEY_KEY, key);
    },
  };
}

/**
 * Browser extension backend using chrome.storage.local.
 */
export function extensionBackend() {
  return {
    async get(key) {
      const result = await chrome.storage.local.get(key);
      return result[key] ?? null;
    },
    async set(key, value) {
      await chrome.storage.local.set({ [key]: value });
    },
  };
}

/**
 * Node.js filesystem backend for CLI usage.
 * Stores data in ~/.unprompted/
 */
export function nodeBackend(dir) {
  const fs = await_import('fs');
  const path = await_import('path');

  function filePath(key) {
    return path.join(dir, key + '.json');
  }

  return {
    async get(key) {
      try {
        return fs.readFileSync(filePath(key), 'utf-8');
      } catch {
        return null;
      }
    },
    async set(key, value) {
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(filePath(key), value, 'utf-8');
    },
  };
}

// Lazy require for Node environments (avoids breaking in browsers)
function await_import(mod) {
  // Dynamic require — only called in Node contexts
  return typeof require !== 'undefined' ? require(mod) : null;
}
