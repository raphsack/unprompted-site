// shared/constants.js — Default sites, idle threshold, sync interval

export const DEFAULT_SITES = [
  'claude.ai',
  'chatgpt.com',
  'gemini.google.com',
  'copilot.microsoft.com',
  'perplexity.ai',
  'poe.com',
  'character.ai',
  'mistral.ai',
];

export const DEFAULT_IDLE_THRESHOLD_SECONDS = 300;   // 5 minutes
export const DEFAULT_SYNC_INTERVAL_MINUTES = 15;
export const DEFAULT_NUDGE_AT = 0.9;                 // 90% of limit
export const DEFAULT_LIMIT_SECONDS = 0;              // 0 = no limit
export const ROLLING_DAYS = 90;
export const SCHEMA_VERSION = 1;
export const WORKER_URL = 'https://unprompted-sync.rjunkspam.workers.dev';
