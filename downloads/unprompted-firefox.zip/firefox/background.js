// Bundled for Firefox MV2 — auto-generated, do not edit
(function() {
"use strict";

// Use browser.* (promise-based) over chrome.* (callback-based) in Firefox
const chrome = globalThis.browser || globalThis.chrome;

// --- constants.js ---
// shared/constants.js — Default sites, idle threshold, sync interval

const DEFAULT_SITES = [
  'claude.ai',
  'chatgpt.com',
  'gemini.google.com',
  'copilot.microsoft.com',
  'perplexity.ai',
  'poe.com',
  'character.ai',
  'mistral.ai',
];

const DEFAULT_IDLE_THRESHOLD_SECONDS = 300;   // 5 minutes
const DEFAULT_SYNC_INTERVAL_MINUTES = 15;
const DEFAULT_NUDGE_AT = 0.9;                 // 90% of limit
const DEFAULT_LIMIT_SECONDS = 0;              // 0 = no limit
const ROLLING_DAYS = 90;
const SCHEMA_VERSION = 1;
const WORKER_URL = 'https://unprompted-sync.rjunkspam.workers.dev';


// --- schema.js ---
// shared/schema.js — Data model: create, validate, merge, prune


/**
 * Create a fresh empty data blob.
 */
function createEmpty() {
  return {
    version: SCHEMA_VERSION,
    days: {},
    limits: {},
    settings: {
      idleThresholdSeconds: DEFAULT_IDLE_THRESHOLD_SECONDS,
      syncIntervalMinutes: DEFAULT_SYNC_INTERVAL_MINUTES,
      nudgeAt: DEFAULT_NUDGE_AT,
    },
    meta: {
      lastSyncedAt: null,
      schemaVersion: SCHEMA_VERSION,
    },
  };
}

/**
 * Add seconds to a site for a given day.
 */
function addTime(data, date, site, seconds) {
  if (!data.days[date]) data.days[date] = {};
  data.days[date][site] = (data.days[date][site] || 0) + seconds;
  return data;
}

/**
 * Get total seconds for a site on a given day.
 */
function getTime(data, date, site) {
  return data.days[date]?.[site] || 0;
}

/**
 * Get total seconds across all sites for a given day.
 */
function getDayTotal(data, date) {
  const day = data.days[date];
  if (!day) return 0;
  return Object.values(day).reduce((sum, s) => sum + s, 0);
}

/**
 * Max-merge two data blobs. Per site per day, take the higher value.
 * Limits and settings are taken from local (the user's device is authoritative).
 */
function merge(local, remote) {
  const merged = structuredClone(local);

  for (const [date, sites] of Object.entries(remote.days)) {
    if (!merged.days[date]) merged.days[date] = {};
    for (const [site, seconds] of Object.entries(sites)) {
      merged.days[date][site] = Math.max(merged.days[date][site] || 0, seconds);
    }
  }

  return merged;
}

/**
 * Remove days older than ROLLING_DAYS from today.
 */
function prune(data, today) {
  const cutoff = new Date(today);
  cutoff.setDate(cutoff.getDate() - ROLLING_DAYS);
  const cutoffStr = formatDate(cutoff);

  for (const date of Object.keys(data.days)) {
    if (date < cutoffStr) delete data.days[date];
  }
  return data;
}

/**
 * Format a Date as YYYY-MM-DD.
 */
function formatDate(d) {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Get today's date string in local time.
 */
function todayString() {
  return formatDate(new Date());
}


// --- crypto.js ---
// shared/crypto.js — Key derivation and AES-GCM encrypt/decrypt
// Works in both browser (Web Crypto) and Node.js (globalThis.crypto)

const subtle = globalThis.crypto.subtle;

const HKDF_INFO = new TextEncoder().encode('unprompted-v1');
const HKDF_SALT = new Uint8Array(32); // zero salt — secret_key already has full entropy

/**
 * Generate a new secret key: 32 random bytes as hex, prefixed "stime_"
 */
function generateSecretKey() {
  const bytes = new Uint8Array(32);
  globalThis.crypto.getRandomValues(bytes);
  return 'stime_' + bytesToHex(bytes);
}

/**
 * Derive the storage key (R2 path) from a secret key.
 * storage_key = SHA-256(secret_key) as hex
 */
async function deriveStorageKey(secretKey) {
  const encoded = new TextEncoder().encode(secretKey);
  const hash = await subtle.digest('SHA-256', encoded);
  return bytesToHex(new Uint8Array(hash));
}

/**
 * Derive an auth token from a secret key for worker authentication.
 * auth_token = SHA-256(secret_key + ":auth") as hex
 */
async function deriveAuthToken(secretKey) {
  const encoded = new TextEncoder().encode(secretKey + ':auth');
  const hash = await subtle.digest('SHA-256', encoded);
  return bytesToHex(new Uint8Array(hash));
}

/**
 * Derive an AES-GCM encryption key from a secret key using HKDF-SHA256.
 */
async function deriveEncryptionKey(secretKey) {
  const keyMaterial = await subtle.importKey(
    'raw',
    new TextEncoder().encode(secretKey),
    'HKDF',
    false,
    ['deriveKey']
  );
  return subtle.deriveKey(
    { name: 'HKDF', hash: 'SHA-256', salt: HKDF_SALT, info: HKDF_INFO },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

/**
 * Encrypt a plaintext JSON string with AES-GCM.
 * Returns a base64 string (IV prepended to ciphertext).
 */
async function encrypt(secretKey, plaintext) {
  const key = await deriveEncryptionKey(secretKey);
  const iv = globalThis.crypto.getRandomValues(new Uint8Array(12));
  const encoded = new TextEncoder().encode(plaintext);
  const ciphertext = await subtle.encrypt({ name: 'AES-GCM', iv }, key, encoded);

  // Prepend 12-byte IV to ciphertext
  const combined = new Uint8Array(iv.length + ciphertext.byteLength);
  combined.set(iv);
  combined.set(new Uint8Array(ciphertext), iv.length);

  return bytesToBase64(combined);
}

/**
 * Decrypt a base64 string (IV + ciphertext) back to plaintext.
 */
async function decrypt(secretKey, base64Ciphertext) {
  const key = await deriveEncryptionKey(secretKey);
  const combined = base64ToBytes(base64Ciphertext);

  const iv = combined.slice(0, 12);
  const ciphertext = combined.slice(12);

  const decrypted = await subtle.decrypt({ name: 'AES-GCM', iv }, key, ciphertext);
  return new TextDecoder().decode(decrypted);
}

// --- Helpers ---

function bytesToHex(bytes) {
  return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
}

function bytesToBase64(bytes) {
  if (typeof Buffer !== 'undefined') {
    return Buffer.from(bytes).toString('base64');
  }
  // Browser fallback
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}

function base64ToBytes(base64) {
  if (typeof Buffer !== 'undefined') {
    return new Uint8Array(Buffer.from(base64, 'base64'));
  }
  // Browser fallback
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}


// --- storage.js ---
// shared/storage.js — Local read/write, abstracted per surface
// Each surface provides a backend: { get(key), set(key, value) }


const DATA_KEY = 'unprompted-data';
const SECRET_KEY_KEY = 'unprompted-secret';

/**
 * Create a storage adapter for a given backend.
 *
 * Backends:
 *   - Browser extension: chrome.storage.local (async)
 *   - Node/CLI: filesystem-based (see nodeBackend below)
 */
function createStorage(backend) {
  return {
    async loadData() {
      const raw = await backend.get(DATA_KEY);
      if (!raw) return createEmpty();
      return typeof raw === 'string' ? JSON.parse(raw) : raw;
    },

    async saveData(data) {
      await backend.set(DATA_KEY, JSON.stringify(data));
    },

    async getSecretKey() {
      return backend.get(SECRET_KEY_KEY);
    },

    async setSecretKey(key) {
      await backend.set(SECRET_KEY_KEY, key);
    },
  };
}

/**
 * Browser extension backend using chrome.storage.local.
 */
function extensionBackend() {
  return {
    async get(key) {
      const result = await chrome.storage.local.get(key);
      return result[key] ?? null;
    },
    async set(key, value) {
      await chrome.storage.local.set({ [key]: value });
    },
  };
}

/**
 * Node.js filesystem backend for CLI usage.
 * Stores data in ~/.unprompted/
 */
function nodeBackend(dir) {
  const fs = await_import('fs');
  const path = await_import('path');

  function filePath(key) {
    return path.join(dir, key + '.json');
  }

  return {
    async get(key) {
      try {
        return fs.readFileSync(filePath(key), 'utf-8');
      } catch {
        return null;
      }
    },
    async set(key, value) {
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(filePath(key), value, 'utf-8');
    },
  };
}

// Lazy require for Node environments (avoids breaking in browsers)
function await_import(mod) {
  // Dynamic require — only called in Node contexts
  return typeof require !== 'undefined' ? require(mod) : null;
}


// --- sync.js ---
// shared/sync.js — Encrypt, upload, download, merge
// Depends on crypto.js (encrypt/decrypt, deriveStorageKey) and schema.js (merge, prune)



/**
 * Perform a full sync cycle:
 *   1. Download remote blob (if any)
 *   2. Decrypt and max-merge into local
 *   3. Prune old days
 *   4. Encrypt and upload merged blob
 *   5. Save merged blob locally
 *
 * @param {object} storage — from createStorage()
 * @param {string} workerUrl — base URL of Cloudflare Worker (no trailing slash)
 * @param {function} fetchFn — fetch implementation (globalThis.fetch or node-fetch)
 * @returns {{ merged: boolean, uploaded: boolean }} result summary
 */
async function sync(storage, workerUrl, fetchFn = globalThis.fetch) {
  const secretKey = await storage.getSecretKey();
  if (!secretKey) return { merged: false, uploaded: false };

  const storageKey = await deriveStorageKey(secretKey);
  const authToken = await deriveAuthToken(secretKey);
  const endpoint = `${workerUrl}/sync/${storageKey}`;

  let local = await storage.loadData();
  let merged = false;

  // Download and merge
  const remote = await download(secretKey, authToken, endpoint, fetchFn);
  if (remote) {
    local = merge(local, remote);
    merged = true;
  }

  // Prune rolling window
  local = prune(local, todayString());
  local.meta.lastSyncedAt = new Date().toISOString();

  // Upload
  const uploaded = await upload(secretKey, authToken, endpoint, local, fetchFn);

  // Save locally
  await storage.saveData(local);

  return { merged, uploaded };
}

/**
 * Download and decrypt the remote blob. Returns parsed data or null.
 */
async function download(secretKey, authToken, endpoint, fetchFn) {
  try {
    const res = await fetchFn(endpoint, {
      method: 'GET',
      headers: { 'Authorization': `Bearer ${authToken}` }
    });
    if (!res.ok) return null;
    const { ciphertext } = await res.json();
    if (!ciphertext) return null;
    const plaintext = await decrypt(secretKey, ciphertext);
    return JSON.parse(plaintext);
  } catch {
    return null;
  }
}

/**
 * Encrypt and upload the local blob.
 */
async function upload(secretKey, authToken, endpoint, data, fetchFn) {
  try {
    const plaintext = JSON.stringify(data);
    const ciphertext = await encrypt(secretKey, plaintext);
    const res = await fetchFn(endpoint, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`
      },
      body: JSON.stringify({ ciphertext }),
    });
    return res.ok;
  } catch {
    return false;
  }
}


// --- background.js ---
// extension/shared/background.js — Service worker: tracking, sync timer





const storage = createStorage(extensionBackend());

// --- In-memory tracking state ---
let activeSession = null;   // { site, startTime }
let idle = false;
let lastInteractionAt = Date.now();

// --- Helpers ---

function extractSite(url) {
  try {
    const hostname = new URL(url).hostname;
    return DEFAULT_SITES.find(s => hostname === s || hostname.endsWith('.' + s)) || null;
  } catch {
    return null;
  }
}

async function flushSession() {
  if (!activeSession) return;
  const elapsed = Math.round((Date.now() - activeSession.startTime) / 1000);
  if (elapsed > 0) {
    const data = await storage.loadData();
    addTime(data, todayString(), activeSession.site, elapsed);
    await storage.saveData(data);
    await checkNudge(data, activeSession.site);
  }
  activeSession = null;
}

function startSession(site) {
  activeSession = { site, startTime: Date.now() };
  idle = false;
}

async function onTabChanged(tabId) {
  await flushSession();
  try {
    const tab = await chrome.tabs.get(tabId);
    const site = extractSite(tab.url);
    if (site) startSession(site);
  } catch {
    // Tab may not exist
  }
}

// --- Tab / window listeners ---

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  await onTabChanged(tabId);
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.url || changeInfo.status === 'complete') {
    // Only care if this is the active tab
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (activeTab && activeTab.id === tabId) {
      await onTabChanged(tabId);
    }
  }
});

chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    // All windows lost focus
    await flushSession();
    return;
  }
  try {
    const [activeTab] = await chrome.tabs.query({ active: true, windowId });
    if (activeTab) await onTabChanged(activeTab.id);
  } catch {
    await flushSession();
  }
});

// --- Nudge ---

async function checkNudge(data, site) {
  const limit = data.limits?.[site];
  if (!limit) return;
  const nudgeAt = data.settings?.nudgeAt ?? 0.9;
  const current = getTime(data, todayString(), site);
  if (current >= limit * nudgeAt) {
    const remaining = Math.max(0, limit - current);
    const minutes = Math.ceil(remaining / 60);
    // Find tabs for this site and send nudge
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (extractSite(tab.url) === site) {
        chrome.tabs.sendMessage(tab.id, {
          type: 'nudge',
          site,
          minutesLeft: minutes,
        }).catch(() => {});
      }
    }
  }
}

// --- Sync alarm ---

chrome.alarms.create('sync', { periodInMinutes: 15 });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'sync') {
    await flushSession();
    await sync(storage, WORKER_URL);
    // Restart session if a tracked tab is still active
    try {
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (activeTab) {
        const site = extractSite(activeTab.url);
        if (site) startSession(site);
      }
    } catch {}
  }
});

// --- All message handling (single listener to avoid Firefox MV2 multi-listener bug) ---

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'heartbeat') {
    lastInteractionAt = msg.lastInteractionAt;
    const thresholdMs = (msg.idleThreshold || DEFAULT_IDLE_THRESHOLD_SECONDS) * 1000;
    const wasIdle = idle;
    idle = (Date.now() - lastInteractionAt) > thresholdMs;

    if (idle && !wasIdle && activeSession) {
      flushSession();
    } else if (!idle && wasIdle) {
      if (sender.tab?.url) {
        const site = extractSite(sender.tab.url);
        if (site) startSession(site);
      }
    }

    // MV3 fix: service worker can suspend and lose activeSession.
    // If heartbeat arrives from a tracked site with no session, start one.
    if (!idle && !activeSession && sender.tab?.url) {
      const site = extractSite(sender.tab.url);
      if (site) startSession(site);
    }

    // Check nudge on every heartbeat so user gets warned even without tab changes
    if (!idle && activeSession) {
      flushSession().then(() => storage.loadData()).then(data => {
        const site = activeSession?.site || extractSite(sender.tab?.url);
        if (site) checkNudge(data, site);
        // Restart session after flush
        if (!activeSession && sender.tab?.url) {
          const s = extractSite(sender.tab.url);
          if (s) startSession(s);
        }
      }).catch(() => {});
    }

    sendResponse({ ok: true });
    return false;
  }

  if (msg.type === 'getData') {
    // Flush current session so popup sees up-to-date numbers
    flushSession().then(() => storage.loadData()).then(data => {
      // Restart session for the tracked tab (flush cleared it)
      if (activeSession === null) {
        chrome.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
          if (tab) {
            const site = extractSite(tab.url);
            if (site) startSession(site);
          }
        }).catch(() => {});
      }
      sendResponse(data);
    });
    return true;
  }

  if (msg.type === 'saveData') {
    storage.saveData(msg.data).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === 'syncNow') {
    flushSession().then(() => sync(storage, WORKER_URL)).then(result => sendResponse(result));
    return true;
  }
});

})();
