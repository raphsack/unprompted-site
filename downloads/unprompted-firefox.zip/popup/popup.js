// extension/shared/popup/popup.js — Popup UI logic

const DEFAULT_SITES = [
  'claude.ai', 'gemini.google.com', 'chatgpt.com', 'copilot.microsoft.com',
  'perplexity.ai', 'poe.com', 'character.ai', 'mistral.ai',
];

const SITE_STYLES = {
  'claude.ai':            { letter: 'C',  bg: '#E6F1FB', color: '#185FA5', bar: '#378ADD' },
  'chatgpt.com':          { letter: 'G',  bg: '#EAF3DE', color: '#3B6D11', bar: '#639922' },
  'gemini.google.com':    { letter: 'G',  bg: '#FAEEDA', color: '#854F0B', bar: '#EF9F27' },
  'copilot.microsoft.com':{ letter: 'Co', bg: '#EDE6FB', color: '#5B21B6', bar: '#7C3AED' },
  'perplexity.ai':        { letter: 'P',  bg: '#E0F5F0', color: '#0D6E5B', bar: '#14B8A6' },
  'poe.com':              { letter: 'P',  bg: '#FCEBEB', color: '#A32D2D', bar: '#DC4C4C' },
  'character.ai':         { letter: 'Ch', bg: '#FCE7F3', color: '#9D174D', bar: '#EC4899' },
  'mistral.ai':           { letter: 'M',  bg: '#E8EAF6', color: '#283593', bar: '#5C6BC0' },
  'claude-code':          { letter: 'CC', bg: '#E6F1FB', color: '#185FA5', bar: '#2563EB' },
};

const DEFAULT_STYLE = { letter: '?', bg: '#f0f0f2', color: '#6b6b76', bar: '#9b9ba4' };

const EMPTY_DATA = {
  version: 1, days: {}, limits: {},
  settings: { idleThresholdSeconds: 300, syncIntervalMinutes: 15, nudgeAt: 0.9 },
  meta: { lastSyncedAt: null, schemaVersion: 1 },
};

let data = null;

// --- Init ---

document.addEventListener('DOMContentLoaded', () => {
  bindWelcome();
  bindSettings();

  // Show UI immediately using local storage (no background script needed)
  chromeGet(['unprompted-onboarded']).then(store => {
    if (!store['unprompted-onboarded']) {
      showWelcome();
    } else {
      // Show main with empty data right away, then backfill
      data = EMPTY_DATA;
      showMain();
    }

    // Fetch real data from background and re-render
    msg('getData').then(d => {
      if (d) {
        data = d;
        if (store['unprompted-onboarded']) {
          renderStats();
          renderSites();
          renderLimits();
        }
      }
    });
  });
});

// --- Welcome ---

function showWelcome() {
  document.getElementById('view-welcome').classList.remove('hidden');
  document.getElementById('main').classList.add('hidden');
}

function showMain() {
  document.getElementById('view-welcome').classList.add('hidden');
  document.getElementById('main').classList.remove('hidden');
  renderStats();
  renderSites();
  renderLimits();
}

function bindWelcome() {
  document.getElementById('welcome-generate').addEventListener('click', () => {
    const bytes = new Uint8Array(32);
    crypto.getRandomValues(bytes);
    const hex = Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
    document.getElementById('welcome-key').value = 'stime_' + hex;
  });

  document.getElementById('welcome-start').addEventListener('click', async () => {
    const key = document.getElementById('welcome-key').value.trim();
    if (key) await chromeSet({ 'unprompted-secret': key });
    await chromeSet({ 'unprompted-onboarded': true });
    showMain();
  });
}

// --- Stats ---

function renderStats() {
  const today = todayString();
  const day = data.days[today] || {};
  const totalSec = Object.values(day).reduce((a, b) => a + b, 0);

  document.getElementById('stat-total').textContent = formatTime(totalSec);

  // vs. yesterday
  const yDate = new Date();
  yDate.setDate(yDate.getDate() - 1);
  const yesterday = fmtDate(yDate);
  const yDay = data.days[yesterday] || {};
  const ySec = Object.values(yDay).reduce((a, b) => a + b, 0);
  const diff = totalSec - ySec;
  const diffEl = document.getElementById('stat-diff');
  if (ySec > 0 || totalSec > 0) {
    const sign = diff >= 0 ? '+' : '';
    diffEl.textContent = `${sign}${formatTime(Math.abs(diff))} vs. yesterday`;
  } else {
    diffEl.textContent = '';
  }

  // budget left: sum of all (limit - used) for sites that have limits
  const limits = data.limits || {};
  const limitedSites = Object.keys(limits).filter(s => limits[s] > 0);
  if (limitedSites.length > 0) {
    const totalLimit = limitedSites.reduce((a, s) => a + limits[s], 0);
    const totalUsed = limitedSites.reduce((a, s) => a + (day[s] || 0), 0);
    const remaining = Math.max(0, totalLimit - totalUsed);
    document.getElementById('stat-budget').textContent = formatTime(remaining);
    const sitesNear = limitedSites.filter(s => (day[s] || 0) >= limits[s] * (data.settings?.nudgeAt ?? 0.9)).length;
    document.getElementById('stat-budget-sub').textContent =
      sitesNear > 0 ? `${sitesNear} site${sitesNear > 1 ? 's' : ''} nearly up` : 'all on track';
  } else {
    document.getElementById('stat-budget').textContent = '--';
    document.getElementById('stat-budget-sub').textContent = 'no limits set';
  }
}

// --- Sites ---

function renderSites() {
  const today = todayString();
  const day = data.days[today] || {};

  // Show sites with activity today, sorted by time desc
  const active = Object.entries(day).filter(([, s]) => s > 0).sort((a, b) => b[1] - a[1]);
  const container = document.getElementById('site-list');
  container.innerHTML = '';

  if (active.length === 0) {
    container.innerHTML = '<div class="empty-state">No AI usage yet today 🎉<div style="font-size:11px;color:var(--text-tertiary);margin-top:6px">Visit ChatGPT, Claude, or other AI sites to start tracking</div></div>';
    return;
  }

  const maxTime = active[0][1];

  for (const [site, seconds] of active) {
    const style = SITE_STYLES[site] || { ...DEFAULT_STYLE, letter: site.charAt(0).toUpperCase() };
    const pct = Math.round((seconds / maxTime) * 100);

    const row = document.createElement('div');
    row.className = 'site-row';

    row.innerHTML = `
      <div class="site-icon" style="background:${style.bg};color:${style.color}">${style.letter}</div>
      <span class="site-name">${site}</span>
      <div class="site-bar"><div class="site-bar-fill" style="width:${pct}%;background:${style.bar}"></div></div>
      <span class="site-time">${formatTime(seconds)}</span>
    `;

    container.appendChild(row);
  }
}

// --- Limits ---

function renderLimits() {
  const today = todayString();
  const day = data.days[today] || {};
  const limits = data.limits || {};
  const nudgeAt = data.settings?.nudgeAt ?? 0.9;

  // Show sites that have limits set
  const limitedSites = Object.entries(limits).filter(([, v]) => v > 0);
  const container = document.getElementById('limits-list');
  container.innerHTML = '';

  if (limitedSites.length === 0) {
    container.innerHTML = '<div class="empty-state">No limits set<div style="font-size:11px;color:var(--text-tertiary);margin-top:6px">Tap "Edit" to set daily limits for your AI tools</div></div>';
    return;
  }

  for (const [site, limit] of limitedSites) {
    const used = day[site] || 0;
    const ratio = used / limit;

    let badgeClass, badgeText;
    if (used >= limit) {
      badgeClass = 'badge-over';
      badgeText = 'over limit';
    } else if (ratio >= nudgeAt) {
      badgeClass = 'badge-warn';
      badgeText = 'nearly up';
    } else {
      badgeClass = 'badge-ok';
      badgeText = 'on track';
    }

    const row = document.createElement('div');
    row.className = 'limit-row';
    row.innerHTML = `
      <span class="limit-name">${site}</span>
      <span class="limit-progress">${formatTime(used)} / ${formatTime(limit)}</span>
      <span class="badge ${badgeClass}">${badgeText}</span>
    `;
    container.appendChild(row);
  }
}

// --- Settings ---

function openSettings() {
  renderSettingsLimits();
  renderSettingsValues();
  document.getElementById('settings-overlay').classList.remove('hidden');
}

async function closeSettings() {
  document.getElementById('settings-overlay').classList.add('hidden');
  // Reload fresh data from background (includes any new time tracked)
  const freshData = await msg('getData');
  if (freshData) {
    data = freshData;
    renderStats();
    renderSites();
    renderLimits();
  }
}

function bindSettings() {
  document.getElementById('gear-btn').addEventListener('click', openSettings);
  document.getElementById('edit-limits-btn').addEventListener('click', openSettings);
  document.getElementById('settings-close').addEventListener('click', closeSettings);

  const revealBtn = document.getElementById('reveal-key');
  const keyInput = document.getElementById('sync-key');
  revealBtn.addEventListener('click', () => {
    const show = keyInput.type === 'password';
    keyInput.type = show ? 'text' : 'password';
    revealBtn.textContent = show ? 'Hide' : 'Show';
  });

  document.getElementById('save-settings').addEventListener('click', async () => {
    // Save preferences
    data.settings.idleThresholdSeconds = parseInt(document.getElementById('idle-threshold').value) || 300;
    data.settings.nudgeAt = (parseInt(document.getElementById('nudge-at').value) || 90) / 100;

    // Save sync key
    const key = keyInput.value.trim();
    if (key) {
      await chromeSet({ 'unprompted-secret': key });
    } else {
      const api = typeof browser !== 'undefined' ? browser : chrome;
      await new Promise(r => api.storage.local.remove('unprompted-secret', r));
    }

    await msg('saveData', { data });
    showStatus('Saved!');
  });

  document.getElementById('sync-now').addEventListener('click', async () => {
    showStatus('Syncing...');
    const result = await msg('syncNow');
    showStatus(result?.uploaded ? 'Synced.' : 'Sync failed or no key set.');
    data = await msg('getData') || EMPTY_DATA;
    renderSettingsLimits();
  });
}

const STEP = 900; // 15 minutes

function renderSettingsLimits() {
  const container = document.getElementById('settings-limits-list');
  container.innerHTML = '';

  const allSites = [...new Set([...DEFAULT_SITES, 'claude-code', ...Object.keys(data.limits || {})])];

  for (const site of allSites) {
    const style = SITE_STYLES[site] || { ...DEFAULT_STYLE, letter: site.charAt(0).toUpperCase() };
    const current = data.limits?.[site] || 0;

    const row = document.createElement('div');
    row.className = 'setting-limit-row';

    const icon = `<div class="site-icon" style="background:${style.bg};color:${style.color}">${style.letter}</div>`;
    const name = `<span class="limit-site-name">${site}</span>`;

    const stepper = document.createElement('div');
    stepper.className = 'limit-stepper';

    const minus = document.createElement('button');
    minus.textContent = '\u2212';
    minus.addEventListener('click', () => {
      const newVal = Math.max(0, current - STEP);
      setLimit(site, newVal);
      renderSettingsLimits();
    });

    const val = document.createElement('span');
    val.className = 'limit-stepper-val' + (current === 0 ? ' off' : '');
    val.textContent = current > 0 ? formatTime(current) : 'Off';
    val.addEventListener('click', () => {
      const input = document.createElement('input');
      input.className = 'limit-stepper-input';
      input.value = current > 0 ? formatTime(current) : '';
      input.placeholder = '1h 30m';
      val.replaceWith(input);
      input.focus();
      input.select();
      const commit = () => {
        const parsed = parseTime(input.value);
        setLimit(site, parsed);
        renderSettingsLimits();
      };
      input.addEventListener('blur', commit);
      input.addEventListener('keydown', e => {
        if (e.key === 'Enter') input.blur();
        if (e.key === 'Escape') { input.value = ''; input.blur(); }
      });
    });

    const plus = document.createElement('button');
    plus.textContent = '+';
    plus.addEventListener('click', () => {
      setLimit(site, current + STEP);
      renderSettingsLimits();
    });

    stepper.appendChild(minus);
    stepper.appendChild(val);
    stepper.appendChild(plus);

    row.innerHTML = icon + name;
    row.appendChild(stepper);
    container.appendChild(row);
  }
}

function setLimit(site, seconds) {
  if (!data.limits) data.limits = {};
  if (seconds > 0) {
    data.limits[site] = seconds;
  } else {
    delete data.limits[site];
  }
  // Auto-save on chip tap
  msg('saveData', { data });
}

function renderSettingsValues() {
  chromeGet('unprompted-secret').then(result => {
    document.getElementById('sync-key').value = result['unprompted-secret'] || '';
  });

  // Preferences: select the matching option
  const idleEl = document.getElementById('idle-threshold');
  const idleVal = String(data.settings?.idleThresholdSeconds ?? 300);
  idleEl.value = [...idleEl.options].some(o => o.value === idleVal) ? idleVal : '300';

  const nudgeEl = document.getElementById('nudge-at');
  const nudgeVal = String(Math.round((data.settings?.nudgeAt ?? 0.9) * 100));
  nudgeEl.value = [...nudgeEl.options].some(o => o.value === nudgeVal) ? nudgeVal : '90';

  // Sync meta
  const meta = document.getElementById('sync-meta');
  if (data.meta?.lastSyncedAt) {
    const d = new Date(data.meta.lastSyncedAt);
    meta.textContent = `Last synced: ${d.toLocaleString()}`;
  } else {
    meta.textContent = 'Never synced';
  }
}

function showStatus(text) {
  const el = document.getElementById('settings-status');
  el.textContent = text;
  setTimeout(() => { el.textContent = ''; }, 3000);
}

// --- Helpers ---

function msg(type, payload = {}) {
  const api = typeof browser !== 'undefined' ? browser : chrome;
  return new Promise(resolve => {
    api.runtime.sendMessage({ type, ...payload }, response => {
      resolve(response);
    });
  });
}

function chromeGet(keys) {
  // Firefox MV2 chrome.* API uses callbacks, not promises
  const api = typeof browser !== 'undefined' ? browser : chrome;
  return new Promise(resolve => api.storage.local.get(keys, resolve));
}

function chromeSet(items) {
  const api = typeof browser !== 'undefined' ? browser : chrome;
  return new Promise(resolve => api.storage.local.set(items, resolve));
}

function todayString() {
  return fmtDate(new Date());
}

function fmtDate(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function formatTime(seconds) {
  if (!seconds || seconds <= 0) return '0m';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (h > 0 && m > 0) return `${h}h ${m}m`;
  if (h > 0) return `${h}h`;
  return `${m}m`;
}

function parseTime(str) {
  str = (str || '').trim().toLowerCase();
  if (!str) return 0;
  let total = 0;
  const hMatch = str.match(/([\d.]+)\s*h/);
  const mMatch = str.match(/([\d.]+)\s*m/);
  if (hMatch) total += parseFloat(hMatch[1]) * 3600;
  if (mMatch) total += parseFloat(mMatch[1]) * 60;
  if (!hMatch && !mMatch) {
    const n = parseFloat(str);
    if (!isNaN(n)) total = n * 60; // bare number = minutes
  }
  return Math.round(total);
}
