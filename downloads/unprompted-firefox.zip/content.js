// extension/shared/content.js — Idle detection via user interaction events

let lastInteractionAt = Date.now();

// Track user activity
for (const event of ['mousemove', 'keydown', 'click', 'scroll']) {
  document.addEventListener(event, () => {
    lastInteractionAt = Date.now();
  }, { passive: true });
}

// Ping background every 30 seconds (keeps MV3 service worker alive + recovers from suspension)
setInterval(() => {
  chrome.runtime.sendMessage({
    type: 'heartbeat',
    lastInteractionAt,
  }).catch(() => {});
}, 30_000);

// --- Nudge banner ---

let nudgeDismissedUntil = {};  // { site: timestamp } — cooldown after dismiss

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'nudge') {
    const cooldownUntil = nudgeDismissedUntil[msg.site] || 0;
    if (Date.now() > cooldownUntil) {
      showNudge(msg.site, msg.minutesLeft);
    }
  }
});

function showNudge(site, minutesLeft) {
  // Remove any existing banner before showing new one
  const existing = document.getElementById('llm-screentime-nudge');
  if (existing) existing.remove();

  const banner = document.createElement('div');
  banner.id = 'llm-screentime-nudge';
  banner.style.cssText = `
    position: fixed; top: 0; left: 0; right: 0; z-index: 2147483647;
    background: #1a1a2e; color: #e0e0e0; font-family: system-ui, sans-serif;
    font-size: 14px; padding: 10px 16px; display: flex; align-items: center;
    justify-content: space-between; box-shadow: 0 2px 8px rgba(0,0,0,0.3);
  `;

  const left = document.createElement('span');
  left.style.cssText = 'display: flex; align-items: center; gap: 8px;';

  const logo = document.createElement('span');
  logo.textContent = '\u23f1\ufe0f'; // stopwatch emoji — placeholder for logo
  logo.style.cssText = 'font-size: 18px; line-height: 1;';

  const text = document.createElement('span');
  text.textContent = minutesLeft > 0
    ? `Unprompted: ${minutesLeft} min left on ${site} today`
    : `Unprompted: You're past your daily limit on ${site}`;

  left.appendChild(logo);
  left.appendChild(text);

  const dismiss = document.createElement('button');
  dismiss.textContent = 'Got it';
  dismiss.style.cssText = `
    background: #333; color: #fff; border: 1px solid #555; border-radius: 4px;
    padding: 4px 12px; cursor: pointer; font-size: 13px; margin-left: 12px;
    white-space: nowrap;
  `;
  dismiss.onclick = () => {
    nudgeDismissedUntil[site] = Date.now() + 10 * 60 * 1000; // 10 min cooldown
    banner.remove();
  };

  banner.appendChild(left);
  banner.appendChild(dismiss);
  document.body.appendChild(banner);
}
